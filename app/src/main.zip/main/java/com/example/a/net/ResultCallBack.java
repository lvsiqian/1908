package com.example.a.net;

public interface ResultCallBack <T>{
    void onsuccess(T pbean);
}

package com.example.a.view;

import com.example.a.Pbean;

public interface Mainview {
    void onsuccess(Pbean pbean);
}
